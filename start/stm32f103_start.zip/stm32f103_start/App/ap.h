/*
 * ap.h
 *
 *  Created on: May 21, 2024
 *      Author: ljy
 */

#ifndef AP_H_
#define AP_H_


void apInit(void);
void apMain(void);

#endif /* AP_H_ */
