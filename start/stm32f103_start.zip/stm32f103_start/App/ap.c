/*
 * ap.c
 *
 *  Created on: May 21, 2024
 *      Author: ljy
 */


#include "ap.h"



void apInit(void)
{

}

void apMain(void)
{
	while(1)
	{

	}
}
